# SOC 101

This is the *public* repository for the SOC 101 curriculum.

## If you're here from YouTube, you are in the wrong repository.

## Frequently Asked Questions (FAQ)
### What are the passwords for the course files?
You can find the current set of passwords in the SOC 101 course within your TCM Security Academy subscription. You can find them under the relevant lab machine setup videos (Configuring Windows and Configuring Ubuntu). Please do not ask or open issues asking what the password is.
