#!/bin/sh
PACKAGES="net-tools hping3"

sudo apt update
sudo apt install -y $PACKAGES

echo "Installation completed! Enjoy the course <3"